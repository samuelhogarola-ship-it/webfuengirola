<?php
/**
 * WF-Studio Blog — functions.php
 */

// Configuración básica del tema
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ] );
	add_theme_support( 'automatic-feed-links' );
	register_nav_menus( [ 'primary' => 'Menú principal' ] );
} );

// Enqueue estilos y fuentes
add_action( 'wp_enqueue_scripts', function () {
	wp_enqueue_style( 'inter-font', 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap', [], null );
	wp_enqueue_style( 'wf-studio-blog', get_stylesheet_uri(), [ 'inter-font' ], '1.0.0' );
} );

// Longitud del excerpt
add_filter( 'excerpt_length', fn() => 22 );
add_filter( 'excerpt_more', fn() => '…' );

/**
 * Tiempo de lectura estimado.
 *
 * @param int|null $post_id ID del post (null usa el post actual del loop).
 * @return string Ej: "3 min de lectura"
 */
function wf_reading_time( $post_id = null ) {
	$content = get_post_field( 'post_content', $post_id ?: get_the_ID() );
	$words   = str_word_count( strip_tags( $content ) );
	$minutes = max( 1, (int) round( $words / 200 ) );
	return $minutes . ' min de lectura';
}
