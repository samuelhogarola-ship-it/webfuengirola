<?php get_header(); ?>

<main id="main">

	<!-- Hero del blog -->
	<section class="blog-hero">
		<div class="container">
			<span class="section-label">Blog</span>
			<h1 class="section-title">Consejos y recursos<br>para tu negocio online</h1>
			<p class="section-sub">Artículos sobre diseño web, SEO local y marketing digital para comercios en la Costa del Sol.</p>
		</div>
	</section>

	<!-- Listado de posts -->
	<section class="posts-section">
		<div class="container">
			<?php if ( have_posts() ) : ?>

				<div class="posts-grid">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part( 'template-parts/card', 'post' ); ?>
					<?php endwhile; ?>
				</div>

				<div class="pagination">
					<?php
					the_posts_pagination( [
						'mid_size'  => 2,
						'prev_text' => '← Anterior',
						'next_text' => 'Siguiente →',
					] );
					?>
				</div>

			<?php else : ?>

				<div class="no-posts">
					<p>Aún no hay artículos publicados. ¡Vuelve pronto!</p>
					<a href="https://webfuengirola.es" class="btn btn--primary">Volver al inicio</a>
				</div>

			<?php endif; ?>
		</div>
	</section>

</main>

<?php get_footer(); ?>
