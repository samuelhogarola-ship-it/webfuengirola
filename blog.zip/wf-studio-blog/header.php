<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
	<div class="container header-inner">

		<!-- Logo -->
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo" aria-label="WF Studio — inicio">
			<div class="logo-mark" aria-hidden="true">WF</div>
			<div class="logo-text">
				<span class="logo-name">WF Studio</span>
				<span class="logo-sub">Diseño web · Fuengirola</span>
			</div>
		</a>

		<!-- Nav -->
		<nav class="site-nav" aria-label="Navegación principal">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nav-link">Inicio</a>
			<a href="https://webfuengirola.es/servicios.html" class="nav-link">Servicios</a>
			<a href="https://webfuengirola.es/portfolio.html" class="nav-link">Portfolio</a>
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="nav-link active" aria-current="page">Blog</a>
		</nav>

		<!-- CTA -->
		<div class="header-cta">
			<a href="https://webfuengirola.es/#contacto" class="btn btn--primary">
				Pedir presupuesto
			</a>
		</div>

	</div>
</header>
