<?php get_header(); ?>

<main id="main">

	<section class="error-404">
		<div class="container">

			<div class="error-404__code" aria-hidden="true">404</div>
			<h1 class="error-404__title">Página no encontrada</h1>
			<p class="error-404__sub">
				La página que buscas no existe o ha sido movida.<br>
				Quizás puedas encontrar lo que necesitas desde el blog.
			</p>

			<div style="display:flex;gap:12px;justify-content:center;flex-wrap:wrap;">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn--primary">
					Volver al blog
				</a>
				<a href="https://webfuengirola.es" class="btn btn--ghost">
					Ir a WF Studio
				</a>
			</div>

		</div>
	</section>

</main>

<?php get_footer(); ?>
