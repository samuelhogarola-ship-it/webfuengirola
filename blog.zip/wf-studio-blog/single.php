<?php get_header(); ?>

<main id="main">

	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'single-post' ); ?>>
			<div class="container">
				<div class="single-post__inner">

					<!-- Breadcrumb -->
					<nav class="breadcrumb" aria-label="Ruta de navegación">
						<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Blog</a>
						<span aria-hidden="true">→</span>
						<span><?php the_title(); ?></span>
					</nav>

					<!-- Cabecera del post -->
					<header class="single-post__header">
						<?php
						$cats = get_the_category();
						if ( $cats ) : ?>
							<span class="badge"><?php echo esc_html( $cats[0]->name ); ?></span>
						<?php endif; ?>

						<h1 class="single-post__title"><?php the_title(); ?></h1>

						<div class="single-post__meta">
							<span><?php the_author(); ?></span>
							<span aria-hidden="true">·</span>
							<span><?php echo esc_html( get_the_date( 'd M Y' ) ); ?></span>
							<span aria-hidden="true">·</span>
							<span><?php echo esc_html( wf_reading_time() ); ?></span>
						</div>
					</header>

					<!-- Imagen destacada -->
					<?php if ( has_post_thumbnail() ) : ?>
						<div class="single-post__featured-img">
							<?php the_post_thumbnail( 'large', [ 'loading' => 'eager', 'alt' => esc_attr( get_the_title() ) ] ); ?>
						</div>
					<?php endif; ?>

					<!-- Contenido -->
					<div class="single-post__content">
						<?php the_content(); ?>
					</div>

					<!-- Navegación anterior / siguiente -->
					<nav class="post-nav" aria-label="Navegación entre posts">
						<?php
						$prev = get_previous_post();
						$next = get_next_post();

						if ( $prev ) : ?>
							<a href="<?php echo esc_url( get_permalink( $prev ) ); ?>" class="post-nav__link post-nav__link--prev">
								<span class="post-nav__label">← Anterior</span>
								<span class="post-nav__title"><?php echo esc_html( get_the_title( $prev ) ); ?></span>
							</a>
						<?php endif;

						if ( $next ) : ?>
							<a href="<?php echo esc_url( get_permalink( $next ) ); ?>" class="post-nav__link post-nav__link--next">
								<span class="post-nav__label">Siguiente →</span>
								<span class="post-nav__title"><?php echo esc_html( get_the_title( $next ) ); ?></span>
							</a>
						<?php endif; ?>
					</nav>

				</div>
			</div>
		</article>

	<?php endwhile; ?>

	<!-- CTA al final del post -->
	<section class="cta-blog">
		<div class="container">
			<div class="cta-blog__inner">
				<span class="section-label">WF-Studio</span>
				<h2 class="section-title">¿Quieres una web así<br>para tu negocio?</h2>
				<p class="section-sub">Páginas web profesionales en 48 horas desde 300€ + IVA. Diseño, SEO básico y botón de WhatsApp incluidos.</p>
				<div class="cta-blog__actions">
					<a href="https://webfuengirola.es/#contacto" class="btn btn--primary">Pedir presupuesto</a>
					<a href="https://wa.me/34644220965" class="btn btn--whatsapp">WhatsApp</a>
				</div>
			</div>
		</div>
	</section>

</main>

<?php get_footer(); ?>
