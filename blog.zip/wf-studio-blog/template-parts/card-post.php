<article id="post-<?php the_ID(); ?>" <?php post_class( 'post-card' ); ?>>

	<?php if ( has_post_thumbnail() ) : ?>
		<a href="<?php the_permalink(); ?>" class="post-card__img-wrap" aria-hidden="true" tabindex="-1">
			<?php the_post_thumbnail( 'medium_large', [ 'class' => 'post-card__img', 'loading' => 'lazy', 'alt' => esc_attr( get_the_title() ) ] ); ?>
		</a>
	<?php endif; ?>

	<div class="post-card__body">

		<?php
		$cats = get_the_category();
		if ( $cats ) : ?>
			<span class="badge"><?php echo esc_html( $cats[0]->name ); ?></span>
		<?php endif; ?>

		<h2 class="post-card__title">
			<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
		</h2>

		<p class="post-card__excerpt"><?php the_excerpt(); ?></p>

		<div class="post-card__meta">
			<span><?php echo esc_html( get_the_date( 'd M Y' ) ); ?></span>
			<span aria-hidden="true">·</span>
			<span><?php echo esc_html( wf_reading_time() ); ?></span>
		</div>

		<a href="<?php the_permalink(); ?>" class="btn btn--ghost btn--sm">Leer más →</a>

	</div>

</article>
