<footer class="site-footer">
	<div class="container">
		<div class="footer-grid">

			<!-- Columna marca -->
			<div class="footer-brand">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo" aria-label="WF Studio">
					<div class="logo-mark" aria-hidden="true">WF</div>
					<div class="logo-text">
						<span class="logo-name">WF Studio</span>
						<span class="logo-sub">Diseño web · Fuengirola</span>
					</div>
				</a>
				<p class="footer-tagline">Páginas web profesionales para negocios locales en la Costa del Sol.</p>
			</div>

			<!-- Columna Servicios -->
			<div>
				<p class="footer-col-title">Servicios</p>
				<ul class="footer-links">
					<li><a href="https://webfuengirola.es/servicios.html">Diseño web</a></li>
					<li><a href="https://webfuengirola.es/servicios.html">SEO local</a></li>
					<li><a href="https://webfuengirola.es/servicios.html">Tiendas online</a></li>
					<li><a href="https://webfuengirola.es/servicios.html">Mantenimiento web</a></li>
				</ul>
			</div>

			<!-- Columna Legal -->
			<div>
				<p class="footer-col-title">Legal</p>
				<ul class="footer-links">
					<li><a href="#">Aviso legal</a></li>
					<li><a href="#">Política de privacidad</a></li>
					<li><a href="#">Política de cookies</a></li>
				</ul>
			</div>

			<!-- Columna Contacto -->
			<div>
				<p class="footer-col-title">Contacto</p>
				<ul class="footer-links">
					<li>
						<a href="https://wa.me/34644220965">
							WhatsApp
						</a>
					</li>
					<li>
						<a href="mailto:webfuengirola@pm.me">
							webfuengirola@pm.me
						</a>
					</li>
					<li>Fuengirola, Málaga</li>
				</ul>
			</div>

		</div>

		<div class="footer-bottom">
			<p class="footer-copy">
				&copy; <span id="footer-year"></span> WF Studio. Todos los derechos reservados.
			</p>
			<div class="footer-legal">
				<a href="#">Aviso legal</a>
				<a href="#">Privacidad</a>
				<a href="#">Cookies</a>
			</div>
		</div>
	</div>
</footer>

<script>document.getElementById('footer-year').textContent = new Date().getFullYear();</script>

<?php wp_footer(); ?>
</body>
</html>
