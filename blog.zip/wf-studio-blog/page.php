<?php get_header(); ?>

<main id="main">

	<?php while ( have_posts() ) : the_post(); ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class( 'page-content' ); ?>>
			<div class="container">
				<div class="single-post__inner page-content__inner">

					<h1 class="page-content__title"><?php the_title(); ?></h1>

					<div class="single-post__content">
						<?php the_content(); ?>
					</div>

				</div>
			</div>
		</article>

	<?php endwhile; ?>

</main>

<?php get_footer(); ?>
