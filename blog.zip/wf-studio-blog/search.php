<?php get_header(); ?>

<main id="main">

	<!-- Hero de búsqueda -->
	<section class="search-hero">
		<div class="container">
			<span class="section-label">Búsqueda</span>
			<h1 class="section-title">
				<?php if ( get_search_query() ) : ?>
					Resultados para: <em><?php echo esc_html( get_search_query() ); ?></em>
				<?php else : ?>
					Buscar en el blog
				<?php endif; ?>
			</h1>

			<?php get_search_form(); ?>
		</div>
	</section>

	<!-- Resultados -->
	<section class="posts-section">
		<div class="container">
			<?php if ( have_posts() ) : ?>

				<div class="posts-grid">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part( 'template-parts/card', 'post' ); ?>
					<?php endwhile; ?>
				</div>

				<div class="pagination">
					<?php
					the_posts_pagination( [
						'mid_size'  => 2,
						'prev_text' => '← Anterior',
						'next_text' => 'Siguiente →',
					] );
					?>
				</div>

			<?php else : ?>

				<div class="no-posts">
					<p>No se encontraron resultados para <strong>&ldquo;<?php echo esc_html( get_search_query() ); ?>&rdquo;</strong>.</p>
					<p>Prueba con otras palabras clave o vuelve al blog.</p>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn--primary">Ver todos los artículos</a>
				</div>

			<?php endif; ?>
		</div>
	</section>

</main>

<?php get_footer(); ?>
