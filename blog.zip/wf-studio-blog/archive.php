<?php get_header(); ?>

<main id="main">

	<!-- Hero de archivo -->
	<section class="archive-hero">
		<div class="container">
			<span class="section-label">Archivo</span>
			<h1 class="section-title">
				<?php
				if ( is_category() ) {
					echo 'Categoría: ' . esc_html( single_cat_title( '', false ) );
				} elseif ( is_tag() ) {
					echo 'Etiqueta: ' . esc_html( single_tag_title( '', false ) );
				} elseif ( is_author() ) {
					echo 'Autor: ' . esc_html( get_the_author() );
				} elseif ( is_year() ) {
					echo 'Año: ' . esc_html( get_the_date( 'Y' ) );
				} elseif ( is_month() ) {
					echo esc_html( get_the_date( 'F Y' ) );
				} else {
					the_archive_title();
				}
				?>
			</h1>
			<?php
			$archive_desc = get_the_archive_description();
			if ( $archive_desc ) : ?>
				<p class="section-sub"><?php echo wp_kses_post( $archive_desc ); ?></p>
			<?php endif; ?>
		</div>
	</section>

	<!-- Listado de posts -->
	<section class="posts-section">
		<div class="container">
			<?php if ( have_posts() ) : ?>

				<div class="posts-grid">
					<?php while ( have_posts() ) : the_post(); ?>
						<?php get_template_part( 'template-parts/card', 'post' ); ?>
					<?php endwhile; ?>
				</div>

				<div class="pagination">
					<?php
					the_posts_pagination( [
						'mid_size'  => 2,
						'prev_text' => '← Anterior',
						'next_text' => 'Siguiente →',
					] );
					?>
				</div>

			<?php else : ?>

				<div class="no-posts">
					<p>No hay artículos en esta sección todavía.</p>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="btn btn--primary">Ver todos los artículos</a>
				</div>

			<?php endif; ?>
		</div>
	</section>

</main>

<?php get_footer(); ?>
